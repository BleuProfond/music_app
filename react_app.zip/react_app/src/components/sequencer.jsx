import React from 'react';

class GridContainer extends React.Component {

  render() {
    return(
      <table>
        <tr>
          <td>
            <div>hello</div>
          </td>
        </tr>
      </table>
    )
  }

}

class OnOffSwitch extends React.Component {

  render() {
    return(
      <td>
        <div></div>
      </td>
    )
  }

}

export default GridContainer;
